# @chlohal/coal-ui

Independent React 19 components. Original implementations and square-edged, charcoal/copper styling. No UI-library runtime dependencies. No Tailwind configuration required.

This version is an installable local package; it has not been published to npm.

```sh
npm install ./chlohal-coal-ui-0.4.0.tgz
```

```tsx
import { Button, Input, Label } from '@chlohal/coal-ui';
import '@chlohal/coal-ui/styles.css';

export function Contact() {
  return <form>
    <Label htmlFor="email">Email</Label>
    <Input id="email" name="email" type="email" required />
    <Button type="submit">Continue</Button>
  </form>;
}
```

React and react-dom 19 are peer dependencies. Import CSS once in your application entry point. For Next.js, put the stylesheet import in app/layout.tsx. No global reset is included.

Customize `--coal-bg`, `--coal-fg`, `--coal-primary`, `--coal-border`, `--coal-brand` and other prefixed tokens. Add `.dark` or use a `.coal-theme` element with `data-theme="dark"` for dark styling. Portaled floating content inherits the document theme; put `.dark` on the document element when using portals.

Compound components include Dialog, Tabs, Accordion, Select, Combobox and Popover. Forms use native inputs; dialogs use the native HTML dialog top layer. The Calendar supports single, multiple and range selection. Combobox supports string options and single selection. Field validation is controlled with the `invalid` prop. Native scrollbars are used for ScrollArea.

Supported baseline: current evergreen browsers with HTMLDialogElement.showModal, ResizeObserver and CSS color-mix. Test accessibility in the context of your application, especially labels, focus order and nested overlays.

MIT. See the local catalog for complete runnable examples and API notes.
